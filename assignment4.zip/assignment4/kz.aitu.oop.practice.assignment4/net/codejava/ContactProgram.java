package net.codejava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

public class ContactProgram {

	public static void main(String[] args) {
		String jdbcURL = "jdbc:postgresql://localhost:5432/ITcompany";
		String username = "postgres";
		String password = "123";
		
		try {
			Connection connection = DriverManager.getConnection(jdbcURL, username, password);
			System.out.println("Connected to the PostgreSQL server");
			
			String sql = "INSERT INTO employees (first_name, last_name, email) VALUES (?, ?, ?)";
			
			PreparedStatement statement = connection.prepareStatement(sql); 
			
			statement.setString(1, "John");
			statement.setString(2, "Doe");
			statement.setString(3, "john.doe@gmail.com");
			
			int rows = statement.executeUpdate();
			if (rows > 0) {
				 System.out.println("A new contact has been inserted");
			}
			
			connection.close();
			
		} catch (SQLException e) {
			System.out.println("Error in connection to the PostgreSQL server");
			e.printStackTrace();
		}
		
	}

}
